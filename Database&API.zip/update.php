<?php
error_reporting(E_ERROR | E_PARSE);
$conn = new mysqli("localhost", "root", "mysql", "berita_uas");
if($conn->connect_errno) {
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to connect DB'));
    die();
}

extract($_GET);
if(isset($username, $newpass, $depan, $belakang)){
    $sql = "update users
        set nama_depan=?, nama_belakang=?, `password`=?
        where username=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssss', $depan, $belakang, $newpass, $username);
    $stmt->execute();
    if(!$stmt->errno){
        echo json_encode(true);
    }
    else{
        echo json_encode(false);
        die();
    }
}
else{
    echo json_encode(false);
}