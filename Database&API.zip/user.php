<?php
error_reporting(E_ERROR | E_PARSE);
$conn = new mysqli("localhost", "root", "mysql", "berita_uas");
if($conn->connect_errno) {
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to connect DB'));
    die();
}


if(isset($_GET['username'])){
    $sql = "select * from users where username= ? and password= ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $_GET['username'], $_GET['password']);
    $stmt->execute();
    $res = $stmt->get_result();
    if($row = $res->fetch_assoc()){
        echo json_encode($row);
    }
}

$conn->close();
// if(!$stmt->errno){
//     $id = $stmt->insert_id;
//     $sql2 = "insert into paragraph(user_username, cerbung_id, text) values(?,?,?)";
//     $stmt2 = $conn->prepare($sql2);
//     $stmt2->bind_param("sis", $user, $id, $text);
//     $stmt2->execute();
//     if(!$stmt2->errno){
//         echo json_encode(array('result' => 'OK', 'data' => "OK"));
//     }
//     else{
//         echo json_encode(array('result' => 'ERR', 'data' => $stmt2->error));
//         die();
//     }
// }
// else{
//     echo json_encode(array('result' => 'ERR', 'data' => $stmt->error));
// }

