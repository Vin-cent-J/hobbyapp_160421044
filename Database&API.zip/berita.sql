-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: berita_uas
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `beritas`
--

DROP TABLE IF EXISTS `beritas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beritas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` mediumtext DEFAULT NULL,
  `desc` mediumtext DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `url` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_beritas_users1_idx` (`users_id`),
  CONSTRAINT `fk_beritas_users1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `beritas`
--

LOCK TABLES `beritas` WRITE;
/*!40000 ALTER TABLE `beritas` DISABLE KEYS */;
INSERT INTO `beritas` VALUES (1,'Minisforum V3 tablet arrives — the world\'s first AMD Ryzen 7 8840U-powered Surface clone','The Minisforum V3 tablet is the latest Ryzen 7 Hawk Point-powered PC to join the market. This time, it breaks from Minisforum\'s usual Mini PC flair in favor of the 3-in-1 tablet form factor popularized by Microsoft Surface and Lenovo Yoga tablet PCs.',1,'https://cdn.mos.cms.futurecdn.net/84XyuxK2hoWb4TJW2gWFzn-1200-80.png.webp'),(2,'Samsung plans big capacity jump for SSDs, preps 290-layer V-NAND this year, 430-layer for 2025','The new generation of Samsung\'s 3D NAND memory will feature 290 active layers, which is hardly a significant increase from 236 layers, but this brings with it a substantial change in how these flash devices are made. ',1,'https://cdn.mos.cms.futurecdn.net/YRxhCjYiCQfuyVhkYHkkr7-1200-80.png.webp'),(3,'Google unveils Axion CPU for datacenters: claims up to 50% better performance than x86 processors','The company claims its Axion CPU is faster than competing x86 and Arm-based offerings and plans to use it to run workloads that rely on general-purpose computing at its datacenters.',4,'https://cdn.mos.cms.futurecdn.net/WAtABzrbC9v9vXrF7j95ML-1200-80.jpg.webp');
/*!40000 ALTER TABLE `beritas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `text` mediumtext DEFAULT NULL,
  `beritas_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pages_beritas_idx` (`beritas_id`),
  CONSTRAINT `fk_pages_beritas` FOREIGN KEY (`beritas_id`) REFERENCES `beritas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'This time, it breaks from Minisforum\'s usual Mini PC flair in favor of the 3-in-1 tablet form factor popularized by Microsoft Surface and Lenovo Yoga tablet PCs. The Minisforum V3 has a 14-inch screen that can operate in a standard handheld tablet mode, a solo kickstand, and an included magnetic attachable keyboard for more laptop-typical use.',1),(2,'The report about 290-layer 9th Generation V-NAND contradicts Samsung\'s official plans to introduce 3D NAND memory with over 300 layers in 2024, so take the new information with a grain of salt. Meanwhile, it is possible that Samsung decided to reduce the number of active layers in its V-NAND memory to boost yields. Increasing yields at the cost of areal density may be a good way for Samsung to lower the costs of some of the best SSDs that it makes, particularly the drives for mainstream and low-cost systems. ',2),(3,'A key feature of Samsung\'s 9th Generation V-NAND with 290 active layers is a string stacking production technique, according to the report. Manufacturing processes using string stacking involves building a CMOS layer with logic, then a 145-layer 3D NAND memory array on top, and then another 145-layer of 3D NAND flash above that. While this manufacturing technique is a complex one, it is poised to increase yields for 3D NAND memory products with hundreds of layers, as it is easier to build two 145-layer 3D NAND arrays than one 290-layer 3D NAND array. ',2),(4,'Ultimately, the increased number of layers should enable Samsung to increase areal recording density of its 3D NAND devices. Increasing the density of 3D-NAND is a major goal for all NAND memory makers, as demand for flash in the industry is increasing. Increasing the number of layers in 3D NAND devices also increases production efficiency.',2),(5,'Looking ahead, Samsung has aggressive plans for maintaining its position in the 3D NAND flash market by introducing 3D NAND devices with an even higher number of layers, according to the report. Following the launch of the 290-layer V9, the company intends to release a 430-layer 10th generation V-NAND in the second half of 2025, the report says.',2),(6,'The 8-core,16-thread Ryzen 7 8840U has been paired with a 2560 x 1600 16:10 IPS screen that runs at 165 Hz and has a reported 100% DCI-P3 color gamut coverage. Combined with the unique form factor, this should make this device particularly compelling for professionals on the go, especially after some manual calibration is done for color accuracy and not just gamut coverage.',1),(7,'In any case, the Minisforum V3 does look like a nice Windows 3-in-1 tablet, with decent internal specs and features like quad speakers, display-in support for other devices, and full DCI-P3 coverage being a particular highlight. The official listing starts at $1,199 on Minisforum\'s site and includes 32 GB of DRR5-6400 MT/s RAM alongside a 1 TB NVMe Gen 4 drive.',1),(8,'Google asserts that its Axion processors deliver up to 50% greater performance and up to 60% higher energy efficiency compared to contemporary x86-based processors, though it does not disclose with which CPUs it compares its devices. Additionally, the company claims that Axion offers a 30% performance advantage over rival Arm-based CPUs designed for datacenters, but again it does not disclose the exact rival.',3),(9,'Google\'s Axion processor is based on the Neoverse V2 cores (featuring the Arm v9 instruction set architecture), but Google does not disclose how many general-purpose cores the CPU integrates, though a picture of the processor indicates that the unit uses standard dual-rank DDR5 modules. ',3),(10,'One of the advantages that Google Axion-based servers have is that they come outfitted with the company\'s custom Titanium-badged controllers that offload networking, security, and I/O storage processing from the host CPU, which has a positive effect on the performance available to applications. Using purpose-built accelerators to offload certain workloads from the host CPU is one of the ways to increase server performance without significantly increasing its power budget and Google certainly takes advantage of its Titanium platform.',3),(11,'\"Google\'s announcement of the new Axion CPU marks a significant milestone in delivering custom silicon that is optimized for Google\'s infrastructure, and built on our high-performance Arm Neoverse V2 platform,\" said Rene Haas, CEO of Arm. \"Decades of ecosystem investment, combined with Google\'s ongoing innovation and open-source software contributions ensure the best experience for the workloads that matter most to customers running on Arm everywhere.\" ',3),(12,'Google has already initiated deployment of Google services, including BigTable, Spanner, BigQuery, Blobstore, Pub/Sub, Google Earth Engine, and the YouTube Ads platform, on existing Arm-based servers and plans to expand and scale these services on Axion processors in the near future. ',3),(13,'Google was among the first hyperscalers to develop its own custom silicon for its datacenters. The company has deployed several generations of its tensor processing units (TPUs) for its AI services and has special video transcoding units (VCUs) for transcoding YouTube videos.',3),(14,'With its own custom CPU, Google makes another step away from x86 processors from AMD and Intel and while we do not expect x86 to get eliminated from datacenters any time soon, it is evident that Arm is slowly eating AMD\'s and Intel\'s pie.',3);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `nama_depan` varchar(45) DEFAULT NULL,
  `nama_belakang` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'techtwo','tech12','Tim','Martin','techtwo@gmail.com'),(3,'usertest','test','test','test','test'),(4,'test','test','test1','test1','test');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-17 20:55:16
