<?php
error_reporting(E_ERROR | E_PARSE);
$conn = new mysqli("localhost", "root", "mysql", "berita_uas");
if($conn->connect_errno) {
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to connect DB'));
    die();
}

extract($_GET);
if(isset($username, $password, $depan, $belakang, $email)){
    $sql = "insert into users(username, password, nama_depan, nama_belakang, email) values(?, ?, ?, ?, ?) ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssss', $username, $password, $depan, $belakang, $email);
    $stmt->execute();
    if(!$stmt->errno){
        echo json_encode(true);
    }
    else{
        echo json_encode(false);
        die();
    }
}
else{
    echo json_encode(false);
}