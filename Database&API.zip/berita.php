<?php
error_reporting(E_ERROR | E_PARSE);
$conn = new mysqli("localhost", "root", "mysql", "berita_uas");
if($conn->connect_errno) {
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to connect DB'));
    die();
}


if(!isset($_GET['id'])){
    $sql = "select b.id, b.title, b.desc, b.url, u.username
        from beritas as b inner join 
        users u on b.users_id = u.id";
    $res = $conn->query($sql);
    $data  = [];
    while($row = $res->fetch_assoc()){
        $pages = [];
        $sql2 = "select p.text from pages as p where p.beritas_id = ?";
        $stmt = $conn->prepare($sql2);
        $stmt->bind_param('i', $row['id']);
        $stmt->execute();
        $res2 = $stmt->get_result();
        while($row2 = $res2->fetch_assoc()){
            $pages[] = $row2['text'];
        }
        $data[]= ["id"=>$row['id'], "title"=>$row['title'], "desc"=>$row['desc'], "url"=>$row['url'], "username"=>$row['username'], "pages"=>$pages];
    }
    echo json_encode($data);
    $conn->close();
}
else{
    $id = $_GET['id'];
    $sql = "select b.id, b.title, b.desc, b.url, u.username
        from beritas as b inner join 
        users u on b.users_id = u.id 
        where b.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $data  = [];
    while($row = $res->fetch_assoc()){
        $pages = [];
        $sql2 = "select p.text from pages as p where p.beritas_id = ?";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param('i', $row['id']);
        $stmt2->execute();
        $res2 = $stmt2->get_result();
        while($row2 = $res2->fetch_assoc()){
            $pages[] = $row2['text'];
        }
        $data[]= ["id"=>$row['id'], "title"=>$row['title'], "desc"=>$row['desc'], "url"=>$row['url'], "username"=>$row['username'], "pages"=>$pages];
    }
    echo json_encode($data);
    $conn->close();
}


